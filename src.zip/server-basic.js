const express = require('express');
const app = express();

app.get('/protegido', (req, res) => {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        // Esta línea obliga al navegador a abrir el cuadro de login
        res.setHeader('WWW-Authenticate', 'Basic realm="Introduce admin y 1234"');
        return res.status(401).send('Acceso denegado');
    }

    // Decodificamos lo que llega del navegador
    const encoded = authHeader.split(' ')[1];
    const decoded = Buffer.from(encoded, 'base64').toString('utf-8');
    const [user, pass] = decoded.split(':');

    if (user === 'admin' && pass === '1234') {
        res.send('¡Bienvenido al recurso protegido #1!');
    } else {
        // Si fallan los datos, vuelve a pedir credenciales
        res.setHeader('WWW-Authenticate', 'Basic realm="Usuario o clave incorrectos"');
        res.status(401).send('Credenciales incorrectas');
    }
});

app.listen(3000, () => console.log('Servidor Basic Auth en puerto 3000'));