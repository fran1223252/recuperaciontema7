const express = require('express');
const jwt = require('jsonwebtoken');
const app = express();

// Middleware para procesar JSON en las peticiones
app.use(express.json());

const SECRET_KEY = "clave_maestra_web_2026"; // Clave para firmar los tokens

// 1. Ruta de Login: Verifica credenciales y entrega el Token
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Verificación de credenciales según el PDF
    if (username === 'alumno' && password === 'web2026') {
        // Creamos el token (expira en 1 hora)
        const token = jwt.sign(
            { user: username, role: 'estudiante' }, 
            SECRET_KEY, 
            { expiresIn: '1h' }
        );
        res.json({ token }); // Enviamos el token al cliente
    } else {
        res.status(401).send('Login fallido: Credenciales incorrectas');
    }
});

// 2. Ruta protegida: Solo accesible con un Token válido
app.get('/api/datos', (req, res) => {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(403).send('Token requerido');
    }

    // El formato esperado es "Bearer <TOKEN>"
    const token = authHeader.split(' ')[1];

    // Verificamos si el token es auténtico
    jwt.verify(token, SECRET_KEY, (err, decoded) => {
        if (err) {
            return res.status(403).send('Token inválido o expirado');
        }
        // Si es correcto, devolvemos los datos
        res.json({ 
            mensaje: "Acceso con JWT concedido", 
            usuario: decoded.user,
            datos: ["Dato A", "Dato B", "Dato C"] 
        });
    });
});

app.listen(4000, () => console.log('Servidor JWT activo en puerto 4000'));