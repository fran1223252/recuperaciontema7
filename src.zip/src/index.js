import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { AuthProvider } from './AuthContext';
import { TaskProvider } from './context/TaskContext'; // Importamos el contexto de tareas

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <AuthProvider>
      <TaskProvider> {/* Envolvemos aquí para que Column pueda encontrar 'tareas' */}
        <App />
      </TaskProvider>
    </AuthProvider>
  </React.StrictMode>
);