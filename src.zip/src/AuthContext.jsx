import React, { createContext, useState, useEffect } from 'react';
import { jwtDecode } from 'jwt-decode';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  // 1. Intentamos leer el usuario guardado al arrancar
  const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem('google_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const login = (response) => {
    const decoded = jwtDecode(response.credential);
    setUser(decoded);
    // 2. Guardamos en localStorage para que resista el F5
    localStorage.setItem('google_user', JSON.stringify(decoded));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('google_user'); // Limpiamos al salir
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};