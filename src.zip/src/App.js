import React, { useContext, useEffect } from 'react';
import { AuthContext } from './AuthContext';
import Column from './components/Column';
import TaskForm from './components/TaskForm'; // <--- 1. ASEGÚRATE DE ESTA IMPORTACIÓN
import './App.css';

function App() {
  const { user, login, logout } = useContext(AuthContext);

  useEffect(() => {
    /* global google */
    if (window.google && !user) {
      google.accounts.id.initialize({
        client_id: "328705094061-k9jh256991a8j5gvat6487vk54luei7f.apps.googleusercontent.com",
        callback: login,
      });
      google.accounts.id.prompt();
      google.accounts.id.renderButton(
        document.getElementById("googleButton"),
        { theme: "outline", size: "large" }
      );
    }
  }, [login, user]);

  return (
    <div className="App">
      {user ? (
        <>
          <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 20px', background: '#2c3e50', color: 'white' }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <img src={user.picture} alt="Perfil" style={{ borderRadius: '50%', width: '35px', marginRight: '10px' }} />
              <span>Hola, **{user.name}**</span>
            </div>
            <button onClick={logout} style={{cursor: 'pointer'}}>Cerrar Sesión</button>
          </header>

          <main style={{ padding: '20px' }}>
            {/* 2. AQUÍ PONEMOS EL FORMULARIO PARA CREAR TAREAS */}
            <div style={{ marginBottom: '30px', textAlign: 'center' }}>
              <h2>Añadir Nueva Tarea</h2>
              <TaskForm /> 
            </div>

            <div style={{ display: 'flex', gap: '20px' }}>
               <Column title="To Do" status="todo" />
               <Column title="In Progress" status="in-progress" />
               <Column title="Done" status="done" />
            </div>
          </main>
        </>
      ) : (
        <div style={{ textAlign: 'center', marginTop: '100px' }}>
          <h1>Panel Kanban con Google Auth</h1>
          <div id="googleButton"></div>
        </div>
      )}
    </div>
  );
}

export default App;