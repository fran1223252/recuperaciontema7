import React, { createContext, useState, useEffect } from 'react';

export const TaskContext = createContext();

export const TaskProvider = ({ children }) => {
  const [tareas, setTareas] = useState(() => {
    const saved = localStorage.getItem('kanban_tasks');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('kanban_tasks', JSON.stringify(tareas));
  }, [tareas]);

  const agregarTarea = (texto, autor) => {
    const nueva = { id: Date.now(), texto, autor, status: 'todo' };
    setTareas([...tareas, nueva]);
  };

  // ESTA ES LA FUNCIÓN QUE TE FALTA
  const moverTarea = (id, nuevoEstado) => {
    setTareas(tareas.map(t => 
      t.id === id ? { ...t, status: nuevoEstado } : t
    ));
  };

  // IMPORTANTE: Añade 'moverTarea' aquí abajo para que otros archivos la vean
  return (
    <TaskContext.Provider value={{ tareas, agregarTarea, moverTarea }}>
      {children}
    </TaskContext.Provider>
  );
};