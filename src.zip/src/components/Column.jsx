import React, { useContext } from 'react';
import { TaskContext } from '../context/TaskContext';
import TaskCard from './TaskCard';

const Column = ({ title, status }) => {
  // Obtenemos el contexto de tareas
  const taskContext = useContext(TaskContext);

  // Validación de seguridad: Si el contexto no existe, mostramos un error amigable o nada
  // Esto evita el error "Cannot destructure property 'tareas' as it is undefined"
  if (!taskContext) {
    return <div>Error: TaskContext no encontrado. Revisa el Provider en index.js</div>;
  }

  const { tareas } = taskContext;

  // Filtramos las tareas según el estado de la columna
  // Las tareas ahora deberían incluir el campo 'autor' extraído del JWT de Google
  const filteredTasks = tareas.filter(task => task.status === status);

  return (
    <div style={{ 
      flex: 1, 
      backgroundColor: '#ebedf0', 
      padding: '10px', 
      borderRadius: '8px',
      minHeight: '400px',
      margin: '0 10px',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
    }}>
      <h3 style={{ 
        textAlign: 'center', 
        color: '#172b4d',
        borderBottom: '2px solid #ddd',
        paddingBottom: '10px' 
      }}>
        {title} ({filteredTasks.length})
      </h3>
      
      <div style={{ marginTop: '15px' }}>
        {/* Generamos las tarjetas. Asegúrate de que TaskCard muestre el autor del JWT */}
        {filteredTasks.length > 0 ? (
          filteredTasks.map(task => (
            <TaskCard key={task.id} task={task} />
          ))
        ) : (
          <p style={{ textAlign: 'center', color: '#777', fontSize: '0.9em' }}>
            No hay tareas en esta columna
          </p>
        )}
      </div>
    </div>
  );
};

export default Column;