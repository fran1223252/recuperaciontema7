import React, { useState, useContext } from 'react';
import { TaskContext } from '../context/TaskContext';
import { AuthContext } from '../AuthContext';

const TaskForm = () => {
  const [texto, setTexto] = useState('');
  const { agregarTarea } = useContext(TaskContext);
  const { user } = useContext(AuthContext);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (texto.trim() && user) {
      // Usamos el nombre del usuario de Google como autor
      agregarTarea(texto, user.name); 
      setTexto('');
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ margin: '20px 0' }}>
      <input 
        type="text"
        value={texto} 
        onChange={(e) => setTexto(e.target.value)} 
        placeholder="Escribe una nueva tarea..."
        style={{ padding: '10px', width: '250px' }}
      />
      <button type="submit" style={{ padding: '10px 20px', cursor: 'pointer' }}>
        Añadir Tarea
      </button>
    </form>
  );
};

// ESTA ES LA LÍNEA QUE TE FALTA Y CAUSA EL ERROR:
export default TaskForm;