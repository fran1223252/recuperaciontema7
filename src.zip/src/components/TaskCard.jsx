import React, { useContext } from 'react';
import { TaskContext } from '../context/TaskContext';

const TaskCard = ({ task }) => {
  const { moverTarea } = useContext(TaskContext);

  return (
    <div style={{ 
      background: 'white', 
      padding: '15px', 
      margin: '10px 0', 
      borderRadius: '6px', 
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
      borderLeft: '5px solid #2c3e50'
    }}>
      <p style={{ margin: '0 0 10px 0', fontWeight: 'bold' }}>{task.texto}</p>
      
      {/* REQUISITO JWT: Mostrar el autor que viene de Google */}
      <div style={{ fontSize: '0.8em', color: '#666', marginBottom: '10px' }}>
        👤 Autor: <strong>{task.autor}</strong>
      </div>
      
      <div style={{ display: 'flex', gap: '5px', justifyContent: 'center' }}>
        {/* Si está en To Do, permitimos mover a In Progress */}
        {task.status === 'todo' && (
          <button 
            onClick={() => moverTarea(task.id, 'in-progress')}
            style={{ background: '#3498db', color: 'white', border: 'none', padding: '5px 10px', borderRadius: '4px', cursor: 'pointer' }}
          >
            En curso →
          </button>
        )}

        {/* Si está en In Progress, permitimos mover a Done o devolver a To Do */}
        {task.status === 'in-progress' && (
          <>
            <button 
              onClick={() => moverTarea(task.id, 'todo')}
              style={{ background: '#95a5a6', color: 'white', border: 'none', padding: '5px 10px', borderRadius: '4px', cursor: 'pointer' }}
            >
              ← To Do
            </button>
            <button 
              onClick={() => moverTarea(task.id, 'done')}
              style={{ background: '#27ae60', color: 'white', border: 'none', padding: '5px 10px', borderRadius: '4px', cursor: 'pointer' }}
            >
              Hecho →
            </button>
          </>
        )}

        {/* Si está en Done, permitimos devolver a In Progress por si hubo error */}
        {task.status === 'done' && (
          <button 
            onClick={() => moverTarea(task.id, 'in-progress')}
            style={{ background: '#f39c12', color: 'white', border: 'none', padding: '5px 10px', borderRadius: '4px', cursor: 'pointer' }}
          >
            ↩ Reabrir
          </button>
        )}
      </div>
    </div>
  );
};

export default TaskCard;