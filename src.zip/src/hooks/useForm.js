import { useState } from 'react';

// Custom Hook genérico para formularios [cite: 61, 62]
const useForm = (initialState = {}) => {
  const [values, setValues] = useState(initialState);

  // Función genérica para manejar cambios en los inputs [cite: 66]
  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value
    });
  };

  // Función para limpiar el formulario después de enviar
  const reset = () => {
    setValues(initialState);
  };

  return [values, handleChange, reset];
};

export default useForm;