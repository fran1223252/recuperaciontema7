import { useContext, useEffect } from 'react';
import { AuthContext } from './AuthContext';

function App() {
    const { user, login, logout } = useContext(AuthContext);

    useEffect(() => {
        /* global google */
        if (window.google) {
            google.accounts.id.initialize({
                client_id: "328705094061-qckc9dkgmce55g9ji92575n105ioht1a.apps.googleusercontent.com", // El ID que copiaste de la consola de Google
                callback: login
            });

            // Requisito: Que aparezca la ventana al cargar [cite: 20]
            google.accounts.id.prompt(); 
        }
    }, [login]);

    return (
        <div>
            {user ? (
                <header>
                    <img src={user.picture} alt="perfil" /> {/* Foto del JWT [cite: 31] */}
                    <p>Hola, {user.name}</p> {/* Nombre del JWT [cite: 31] */}
                    <button onClick={logout}>Cerrar Sesión</button>
                </header>
            ) : (
                <h1>Por favor, inicia sesión para usar el Kanban</h1>
            )}
        </div>
    );
}